using System.Windows.Controls;

namespace MailConsole.UI.Controls
{
    public partial class HeaderControl : UserControl
    {
        public HeaderControl()
        {
            InitializeComponent();
        }

        public void SetPageTitle(string title)
        {
            PageTitle.Text = title;
        }
    }
}
