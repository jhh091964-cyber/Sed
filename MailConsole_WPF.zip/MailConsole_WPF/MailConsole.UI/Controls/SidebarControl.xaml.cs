using System.Windows;
using System.Windows.Controls;

namespace MailConsole.UI.Controls
{
    public partial class SidebarControl : UserControl
    {
        public event Action<string>? OnNavigate;

        public SidebarControl()
        {
            InitializeComponent();
        }

        private void NavButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button?.Tag is string pageKey)
            {
                OnNavigate?.Invoke(pageKey);
            }
        }
    }
}
