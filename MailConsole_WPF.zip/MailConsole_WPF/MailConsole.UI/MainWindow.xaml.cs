using System.Windows;
using MailConsole.UI.Views;

namespace MailConsole.UI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Sidebar.OnNavigate += NavigateToPage;
            Header.SetPageTitle("總覽");
            ContentFrame.Navigate(new DashboardView());
        }

        private void NavigateToPage(string pageKey)
        {
            switch (pageKey)
            {
                case "Dashboard":
                    Header.SetPageTitle("總覽");
                    ContentFrame.Navigate(new DashboardView());
                    break;
                case "Recipients":
                    Header.SetPageTitle("收件人");
                    ContentFrame.Navigate(new RecipientsView());
                    break;
                case "SendHistory":
                    Header.SetPageTitle("發送紀錄");
                    ContentFrame.Navigate(new SendHistoryView());
                    break;
                case "Profiles":
                    Header.SetPageTitle("寄件人設定");
                    ContentFrame.Navigate(new ProfilesView());
                    break;
                case "Settings":
                    Header.SetPageTitle("設定");
                    ContentFrame.Navigate(new SettingsView());
                    break;
            }
        }
    }
}
