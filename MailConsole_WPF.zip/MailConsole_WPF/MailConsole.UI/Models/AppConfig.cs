namespace MailConsole.UI.Models;

public sealed class AppConfig
{
    public string WorkerBaseUrl { get; set; } = "";
    public string AppTokenId { get; set; } = "app_001";
    public string AppTokenSecret { get; set; } = ""; // HMAC_KEY (DPAPI 保護)

    public List<Profile> Profiles { get; set; } = new();
    public string? SelectedProfileId { get; set; }

    public UiParams DefaultParams { get; set; } = new();
    public SeedTestConfig SeedTest { get; set; } = new();
}

public sealed class UiParams
{
    public int max_concurrency { get; set; } = 10;
    public int rate_per_sec { get; set; } = 5;
    public int batch_size { get; set; } = 2000;
    public int batch_interval_sec { get; set; } = 60;
    public int retry_max { get; set; } = 2;
}

public sealed class SeedTestConfig
{
    public bool enabled { get; set; } = false;
    public int every_n { get; set; } = 2000;
    public int count_per_batch { get; set; } = 1; // 1-3
    public string subject_prefix { get; set; } = "[SEED]";
    public string seed_recipients_text { get; set; } = ""; // 多個用換行/逗號
}