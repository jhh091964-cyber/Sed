namespace MailConsole.UI.Models;

public sealed class Profile
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "預設";
    public string FromName { get; set; } = "客服";
    public string FromEmail { get; set; } = "support@yourdomain.com";
    public string? ReplyTo { get; set; }
}