using System.Text.Json.Serialization;

namespace MailConsole.UI.Models;

public sealed class CreateJobRequest
{
    [JsonPropertyName("profile_id")]
    public string ProfileId { get; set; } = "";

    [JsonPropertyName("subject")]
    public string Subject { get; set; } = "";

    [JsonPropertyName("html")]
    public string Html { get; set; } = "";

    // 注意：你後端若採用「先建 job 再分段 recipients」，
    // 這裡可以傳空陣列或不使用它；但保留也不影響。
    [JsonPropertyName("recipients")]
    public List<RecipientDto> Recipients { get; set; } = new();

    // ✅ 這裡必須叫 params（不是 params_）
    [JsonPropertyName("params")]
    public WorkerParams Params { get; set; } = new();

    [JsonPropertyName("seed_test")]
    public SeedTestDto SeedTest { get; set; } = new();
}

public sealed class RecipientDto
{
    [JsonPropertyName("email")]
    public string Email { get; set; } = "";

    [JsonPropertyName("name")]
    public string? Name { get; set; }
}

public sealed class WorkerParams
{
    [JsonPropertyName("max_concurrency")]
    public int MaxConcurrency { get; set; } = 10;

    [JsonPropertyName("rate_per_sec")]
    public int RatePerSec { get; set; } = 5;

    [JsonPropertyName("batch_size")]
    public int BatchSize { get; set; } = 2000;

    [JsonPropertyName("batch_interval_sec")]
    public int BatchIntervalSec { get; set; } = 60;

    [JsonPropertyName("retry_max")]
    public int RetryMax { get; set; } = 2;
}

public sealed class SeedTestDto
{
    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; }

    [JsonPropertyName("every_n")]
    public int EveryN { get; set; } = 2000;

    [JsonPropertyName("count_per_batch")]
    public int CountPerBatch { get; set; } = 1;

    [JsonPropertyName("seed_recipients")]
    public List<string> SeedRecipients { get; set; } = new();

    [JsonPropertyName("subject_prefix")]
    public string SubjectPrefix { get; set; } = "[SEED]";
}

public sealed class CreateJobResponse
{
    [JsonPropertyName("job_id")]
    public string JobId { get; set; } = "";

    [JsonPropertyName("accepted_count")]
    public int AcceptedCount { get; set; }

    [JsonPropertyName("invalid_count")]
    public int InvalidCount { get; set; }

    [JsonPropertyName("clamped_params")]
    public WorkerParams? ClampedParams { get; set; }

    [JsonPropertyName("warnings")]
    public List<string>? Warnings { get; set; }
}

public sealed class AddRecipientsResponse
{
    [JsonPropertyName("accepted_added")]
    public int AcceptedAdded { get; set; }

    [JsonPropertyName("invalid_added")]
    public int InvalidAdded { get; set; }

    [JsonPropertyName("total_accepted")]
    public int TotalAccepted { get; set; }
}

public sealed class JobStatusResponse
{
    [JsonPropertyName("job_id")]
    public string JobId { get; set; } = "";

    [JsonPropertyName("status")]
    public string Status { get; set; } = "";

    [JsonPropertyName("accepted_count")]
    public int AcceptedCount { get; set; }

    [JsonPropertyName("invalid_count")]
    public int InvalidCount { get; set; }

    [JsonPropertyName("processed_count")]
    public int ProcessedCount { get; set; }

    [JsonPropertyName("success_count")]
    public int SuccessCount { get; set; }

    [JsonPropertyName("failed_count")]
    public int FailedCount { get; set; }

    [JsonPropertyName("queued_count")]
    public int QueuedCount { get; set; }

    [JsonPropertyName("current_rate")]
    public double CurrentRate { get; set; }

    [JsonPropertyName("err_rate_1m")]
    public double ErrRate1m { get; set; }

    [JsonPropertyName("protection_mode")]
    public bool ProtectionMode { get; set; }

    [JsonPropertyName("protection_reason")]
    public string? ProtectionReason { get; set; }
}

public sealed class ResultsPageResponse
{
    [JsonPropertyName("page")]
    public int Page { get; set; }

    [JsonPropertyName("pageSize")]
    public int PageSize { get; set; }

    [JsonPropertyName("items")]
    public List<ResultItemDto> Items { get; set; } = new();
}

public sealed class ResultItemDto
{
    [JsonPropertyName("type")]
    public string Type { get; set; } = ""; // normal/seed

    [JsonPropertyName("email")]
    public string Email { get; set; } = "";

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; } = ""; // queued/sending/success/failed

    [JsonPropertyName("resend_id")]
    public string? ResendId { get; set; }

    [JsonPropertyName("error_code")]
    public string? ErrorCode { get; set; }

    [JsonPropertyName("error_message")]
    public string? ErrorMessage { get; set; }

    [JsonPropertyName("sent_at")]
    public long? SentAt { get; set; }

    [JsonPropertyName("attempt")]
    public int Attempt { get; set; }
}