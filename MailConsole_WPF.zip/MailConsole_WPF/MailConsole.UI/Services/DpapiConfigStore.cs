using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MailConsole.UI.Services;

public sealed class DpapiConfigStore
{
    private readonly string _path;

    public DpapiConfigStore(string appName = "MailConsole")
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), appName);
        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, "config.dat");
    }

    public void Save<T>(T cfg)
    {
        var json = JsonSerializer.Serialize(cfg);
        var plain = Encoding.UTF8.GetBytes(json);
        var protectedBytes = ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser);
        File.WriteAllBytes(_path, protectedBytes);
    }

    public T? Load<T>()
    {
        if (!File.Exists(_path)) return default;
        var protectedBytes = File.ReadAllBytes(_path);
        var plain = ProtectedData.Unprotect(protectedBytes, null, DataProtectionScope.CurrentUser);
        var json = Encoding.UTF8.GetString(plain);
        return JsonSerializer.Deserialize<T>(json);
    }

    public void Clear()
    {
        if (File.Exists(_path)) File.Delete(_path);
    }
}