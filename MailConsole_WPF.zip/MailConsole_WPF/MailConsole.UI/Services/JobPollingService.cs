using MailConsole.UI.Models;

namespace MailConsole.UI.Services;

public sealed class JobPollingService
{
    private readonly WorkerApiClient _api;
    private CancellationTokenSource? _cts;

    public event Action<JobStatusResponse>? StatusUpdated;
    public event Action<List<ResultItem>>? NewResults;

    public JobPollingService(WorkerApiClient api) => _api = api;

    public void Stop()
    {
        _cts?.Cancel();
        _cts = null;
    }

    public void Start(string jobId, int pollMs = 1500, int pageSize = 200)
    {
        Stop();
        _cts = new CancellationTokenSource();
        _ = Loop(jobId, pollMs, pageSize, _cts.Token);
    }

    private async Task Loop(string jobId, int pollMs, int pageSize, CancellationToken ct)
    {
        int page = 1;
        int lastCountThisPage = 0;

        while (!ct.IsCancellationRequested)
        {
            try
            {
                var st = await _api.GetJobAsync(jobId, ct);
                StatusUpdated?.Invoke(st);

                // 拉結果：簡單增量（先可用，之後再升級游標）
                var res = await _api.GetResultsAsync(jobId, page, pageSize, ct);

                if (res.items.Count > lastCountThisPage)
                {
                    var delta = res.items.Skip(lastCountThisPage).ToList();
                    lastCountThisPage = res.items.Count;
                    if (delta.Count > 0) NewResults?.Invoke(delta);
                }
                else if (res.items.Count == pageSize)
                {
                    // 可能還有下一頁
                    page++;
                    lastCountThisPage = 0;
                }

                await Task.Delay(pollMs, ct);
            }
            catch
            {
                // 網路短暫錯就等一下再重試
                await Task.Delay(2000, ct);
            }
        }
    }
}