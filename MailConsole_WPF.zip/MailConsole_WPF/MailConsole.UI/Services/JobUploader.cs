using MailConsole.UI.Models;

namespace MailConsole.UI.Services;

public sealed class JobUploader
{
    private readonly WorkerApiClient _api;

    public JobUploader(WorkerApiClient api)
    {
        _api = api;
    }

    public async Task<CreateJobResponse> CreateJobAsync(CreateJobRequest req, CancellationToken ct)
    {
        // 推薦做法：先建 job（recipients 傳空即可）
        req.Recipients = new List<RecipientDto>();
        return await _api.PostJsonAsync<CreateJobResponse>("/v1/jobs", req, ct);
    }

    public async Task<AddRecipientsResponse> AddRecipientsChunkAsync(string jobId, List<RecipientDto> chunk, CancellationToken ct)
    {
        return await _api.PostJsonAsync<AddRecipientsResponse>($"/v1/jobs/{jobId}/recipients", chunk, ct);
    }

    public async Task StartAsync(string jobId, CancellationToken ct)
    {
        await _api.PostJsonAsync<object>($"/v1/jobs/{jobId}/start", new { }, ct);
    }

    public async Task PauseAsync(string jobId, CancellationToken ct)
    {
        await _api.PostJsonAsync<object>($"/v1/jobs/{jobId}/pause", new { }, ct);
    }

    public async Task ResumeAsync(string jobId, CancellationToken ct)
    {
        await _api.PostJsonAsync<object>($"/v1/jobs/{jobId}/resume", new { }, ct);
    }

    public async Task CancelAsync(string jobId, CancellationToken ct)
    {
        await _api.PostJsonAsync<object>($"/v1/jobs/{jobId}/cancel", new { }, ct);
    }

    public static IEnumerable<List<T>> Chunk<T>(IReadOnlyList<T> src, int size)
    {
        for (int i = 0; i < src.Count; i += size)
            yield return src.Skip(i).Take(Math.Min(size, src.Count - i)).ToList();
    }
}