using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;

namespace MailConsole.UI.Services;

public sealed class RecipientImportResult
{
    public int TotalLines { get; init; }
    public int ImportedValid { get; init; }     // 去重後有效數
    public int DuplicateCount { get; init; }
    public int InvalidCount { get; init; }
    public IReadOnlyList<RecipientRow> SampleTop100 { get; init; } = Array.Empty<RecipientRow>();
    public IReadOnlyList<string> InvalidLines { get; init; } = Array.Empty<string>();
}

public sealed class RecipientRow
{
    public string Email { get; init; } = "";
    public string? Name { get; init; }
}

public sealed class RecipientImportService
{
    // 基本 email 檢查（不做 MX/SMTP）
    private static readonly Regex EmailRegex =
        new(@"^[^\s@]+@[^\s@]+\.[^\s@]+$", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    /// <summary>
    /// 匯入 TXT/CSV（至少 email 欄位；name 可選）
    /// - TXT：每行一個 email
    /// - CSV：支援 header（email/name），也支援無 header（第一欄 email，第二欄 name）
    /// </summary>
    public async Task<RecipientImportResult> ImportAsync(
        string filePath,
        IProgress<string>? progress,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(filePath))
            throw new ArgumentException("filePath is empty");

        if (!File.Exists(filePath))
            throw new FileNotFoundException("找不到檔案", filePath);

        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        if (ext is not ".txt" and not ".csv")
            throw new InvalidOperationException("只支援 TXT / CSV");

        // 用 HashSet 去重（忽略大小寫）
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var sample = new List<RecipientRow>(capacity: 100);
        var invalidLines = new List<string>();

        int total = 0, valid = 0, dup = 0, invalid = 0;

        progress?.Report("正在讀取檔案…");

        // 逐行讀：不卡 UI、也不爆記憶體（50k 很安全）
        using var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var sr = new StreamReader(fs, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);

        bool isCsv = ext == ".csv";
        bool headerChecked = false;
        int emailIndex = 0;
        int nameIndex = 1;
        bool hasHeader = false;

        while (!sr.EndOfStream)
        {
            ct.ThrowIfCancellationRequested();
            var raw = await sr.ReadLineAsync() ?? "";
            total++;

            var line = raw.Trim();
            if (string.IsNullOrWhiteSpace(line))
                continue;

            string email;
            string? name = null;

            if (!isCsv)
            {
                email = line;
            }
            else
            {
                // CSV：簡單 split（不支援引號逗號內嵌；你需求是名單匯入，足夠）
                var cols = line.Split(',');

                // 第 1 行判斷 header：只做一次
                if (!headerChecked)
                {
                    headerChecked = true;
                    hasHeader = LooksLikeHeader(cols);
                    if (hasHeader)
                    {
                        (emailIndex, nameIndex) = ResolveHeaderIndexes(cols);
                        continue; // 跳過 header 行
                    }
                }

                email = GetCol(cols, emailIndex);
                name = GetCol(cols, nameIndex);
            }

            email = email.Trim();
            if (!IsValidEmail(email))
            {
                invalid++;
                invalidLines.Add(raw);
                continue;
            }

            if (!seen.Add(email))
            {
                dup++;
                continue;
            }

            valid++;

            if (sample.Count < 100)
                sample.Add(new RecipientRow { Email = email, Name = string.IsNullOrWhiteSpace(name) ? null : name.Trim() });

            // 進度回報（每 2000 行一次）
            if (total % 2000 == 0)
                progress?.Report($"已讀取 {total:n0} 行；有效 {valid:n0}，重複 {dup:n0}，格式錯誤 {invalid:n0}");
        }

        progress?.Report($"完成：有效 {valid:n0}，重複 {dup:n0}，格式錯誤 {invalid:n0}");

        return new RecipientImportResult
        {
            TotalLines = total,
            ImportedValid = valid,
            DuplicateCount = dup,
            InvalidCount = invalid,
            SampleTop100 = sample,
            InvalidLines = invalidLines
        };
    }

    public async Task ExportInvalidLinesAsync(
        IEnumerable<string> invalidLines,
        string outputPath,
        CancellationToken ct)
    {
        var list = invalidLines?.ToList() ?? new List<string>();
        if (list.Count == 0) return;

        var dir = Path.GetDirectoryName(outputPath);
        if (!string.IsNullOrWhiteSpace(dir))
            Directory.CreateDirectory(dir);

        await File.WriteAllLinesAsync(outputPath, list, Encoding.UTF8, ct);
    }

    private static bool IsValidEmail(string email) => EmailRegex.IsMatch(email);

    private static bool LooksLikeHeader(string[] cols)
    {
        // 只要第一列或任一列含 email/name 字樣，就視為 header
        return cols.Any(c =>
        {
            var s = c.Trim().Trim('"').ToLowerInvariant();
            return s is "email" or "e-mail" or "mail" or "name";
        });
    }

    private static (int emailIndex, int nameIndex) ResolveHeaderIndexes(string[] cols)
    {
        int e = -1, n = -1;
        for (int i = 0; i < cols.Length; i++)
        {
            var s = cols[i].Trim().Trim('"').ToLowerInvariant();
            if (s is "email" or "e-mail" or "mail") e = i;
            if (s is "name") n = i;
        }
        if (e < 0) e = 0;
        if (n < 0) n = Math.Min(1, cols.Length - 1);
        return (e, n);
    }

    private static string GetCol(string[] cols, int index)
    {
        if (index < 0 || index >= cols.Length) return "";
        return cols[index].Trim().Trim('"');
    }
}