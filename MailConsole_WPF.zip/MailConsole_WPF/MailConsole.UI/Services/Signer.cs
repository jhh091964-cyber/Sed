using System.Security.Cryptography;
using System.Text;

namespace MailConsole.UI.Services;

public static class Signer
{
    public static string NewNonce() => Guid.NewGuid().ToString("N");

    public static string Sha256Hex(byte[] data)
    {
        var hash = SHA256.HashData(data);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public static string HmacSha256Hex(string message, string key)
    {
        var keyBytes = Encoding.UTF8.GetBytes(key);
        using var hmac = new HMACSHA256(keyBytes);
        var sig = hmac.ComputeHash(Encoding.UTF8.GetBytes(message));
        return Convert.ToHexString(sig).ToLowerInvariant();
    }
}