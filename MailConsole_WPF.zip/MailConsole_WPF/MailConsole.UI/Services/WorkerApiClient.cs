using System.Net.Http;
using System.Text;
using System.Text.Json;
using MailConsole.UI.Models;

namespace MailConsole.UI.Services;

public sealed class WorkerApiClient
{
    private readonly HttpClient _http;
    private readonly string _baseUrl;
    private readonly string _appTokenId;
    private readonly string _hmacKey;

    private static readonly JsonSerializerOptions JsonOpt = new()
    {
        PropertyNamingPolicy = null
    };

    public WorkerApiClient(string workerBaseUrl, string appTokenId, string hmacKey, HttpClient? http = null)
    {
        _baseUrl = workerBaseUrl.TrimEnd('/');
        _appTokenId = appTokenId;
        _hmacKey = hmacKey;
        _http = http ?? new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
    }

    public async Task<CreateJobResponse> CreateJobAsync(CreateJobRequest req, CancellationToken ct)
    {
        // 把 params_ 轉成 JSON 的 params
        var payload = new
        {
            profile_id = req.profile_id,
            subject = req.subject,
            html = req.html,
            recipients = req.recipients, // 若你走 chunk，上面可以傳空陣列
            @params = req.params_,
            seed_test = req.seed_test
        };

        return await PostAsync<CreateJobResponse>("/v1/jobs", payload, ct);
    }

    public async Task<AddRecipientsResponse> AddRecipientsChunkAsync(string jobId, List<RecipientDto> chunk, CancellationToken ct)
        => await PostAsync<AddRecipientsResponse>($"/v1/jobs/{jobId}/recipients", chunk, ct);

    public async Task StartJobAsync(string jobId, CancellationToken ct)
        => _ = await PostAsync<object>($"/v1/jobs/{jobId}/start", new { }, ct);

    public async Task PauseAsync(string jobId, CancellationToken ct)
        => _ = await PostAsync<object>($"/v1/jobs/{jobId}/pause", new { }, ct);

    public async Task ResumeAsync(string jobId, CancellationToken ct)
        => _ = await PostAsync<object>($"/v1/jobs/{jobId}/resume", new { }, ct);

    public async Task CancelAsync(string jobId, CancellationToken ct)
        => _ = await PostAsync<object>($"/v1/jobs/{jobId}/cancel", new { }, ct);

    public async Task<JobStatusResponse> GetJobAsync(string jobId, CancellationToken ct)
        => await GetAsync<JobStatusResponse>($"/v1/jobs/{jobId}", ct);

    public async Task<ResultsPageResponse> GetResultsAsync(string jobId, int page, int pageSize, CancellationToken ct)
        => await GetAsync<ResultsPageResponse>($"/v1/jobs/{jobId}/results?page={page}&pageSize={pageSize}", ct);

    private async Task<T> GetAsync<T>(string path, CancellationToken ct)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, _baseUrl + path);
        Sign(req, Array.Empty<byte>());
        var resp = await _http.SendAsync(req, ct);
        var txt = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode) throw new Exception($"HTTP {(int)resp.StatusCode}: {txt}");
        return JsonSerializer.Deserialize<T>(txt, JsonOpt)!;
    }

    private async Task<T> PostAsync<T>(string path, object body, CancellationToken ct)
    {
        var json = JsonSerializer.Serialize(body, JsonOpt);
        var bytes = Encoding.UTF8.GetBytes(json);

        var req = new HttpRequestMessage(HttpMethod.Post, _baseUrl + path);
        req.Content = new StringContent(json, Encoding.UTF8, "application/json");
        Sign(req, bytes);

        var resp = await _http.SendAsync(req, ct);
        var txt = await resp.Content.ReadAsStringAsync(ct);
        if (!resp.IsSuccessStatusCode) throw new Exception($"HTTP {(int)resp.StatusCode}: {txt}");
        return JsonSerializer.Deserialize<T>(txt, JsonOpt)!;
    }

    private void Sign(HttpRequestMessage req, byte[] bodyBytes)
    {
        var ts = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var nonce = Signer.NewNonce();
        var bodyHash = Signer.Sha256Hex(bodyBytes);

        var url = req.RequestUri!;
        var path = url.AbsolutePath;
        var query = url.Query.TrimStart('?');

        var baseStr = string.Join("\n", new[]
        {
            req.Method.Method.ToUpperInvariant(),
            path,
            query,
            ts.ToString(),
            nonce,
            bodyHash
        });

        var sig = Signer.HmacSha256Hex(baseStr, _hmacKey);

        req.Headers.TryAddWithoutValidation("X-App-Token", _appTokenId);
        req.Headers.TryAddWithoutValidation("X-Timestamp", ts.ToString());
        req.Headers.TryAddWithoutValidation("X-Nonce", nonce);
        req.Headers.TryAddWithoutValidation("X-Signature", sig);
    }
}