namespace MailConsole.UI.Utils;

public static class ChunkExtensions
{
    public static IEnumerable<List<T>> ChunkBy<T>(this IReadOnlyList<T> src, int size)
    {
        if (size <= 0) throw new ArgumentOutOfRangeException(nameof(size));
        for (int i = 0; i < src.Count; i += size)
        {
            yield return src.Skip(i).Take(Math.Min(size, src.Count - i)).ToList();
        }
    }
}