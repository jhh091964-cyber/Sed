using System.Windows.Controls;

namespace MailConsole.UI.Views
{
    public partial class DashboardView : Page
    {
        public DashboardView()
        {
            InitializeComponent();
        }
    }
}
