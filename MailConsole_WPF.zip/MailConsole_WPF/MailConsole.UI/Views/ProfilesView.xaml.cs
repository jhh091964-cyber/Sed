using System.Windows.Controls;

namespace MailConsole.UI.Views
{
    public partial class ProfilesView : Page
    {
        public ProfilesView()
        {
            InitializeComponent();
        }
    }
}
