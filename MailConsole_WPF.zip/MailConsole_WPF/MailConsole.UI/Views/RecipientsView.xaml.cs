using System.Windows.Controls;

namespace MailConsole.UI.Views
{
    public partial class RecipientsView : Page
    {
        public RecipientsView()
        {
            InitializeComponent();
        }
    }
}
