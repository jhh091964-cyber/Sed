using System.Windows.Controls;

namespace MailConsole.UI.Views
{
    public partial class SendHistoryView : Page
    {
        public SendHistoryView()
        {
            InitializeComponent();
        }
    }
}
