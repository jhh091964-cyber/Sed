using System.Windows.Controls;

namespace MailConsole.UI.Views
{
    public partial class SettingsView : Page
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}
