# Mail CLI - 所有檔案索引

## 📁 目錄結構

```
mail_cil/
├── send_cli.py              # 主程式（原版，純互動式）
├── enhanced_send_cli.py     # 主程式（增強版，支援設定檔）
├── ssh_tunnel.py            # SSH tunnel 模組
├── resend_provider.py       # Resend API 提供者
├── adaptive.py              # 自適應速率控制
├── config.ini               # 設定檔
├── requirements.txt         # Python 依賴套件
├── run.bat                  # Windows 一鍵啟動腳本
├── run.sh                   # Linux/Mac 一鍵啟動腳本
├── recipients.txt           # 收件人清單範例
├── README.md                # 完整使用說明
├── QUICKSTART.md            # 快速開始指南
├── CHANGES.md               # 變更說明
├── templates/
│   └── mail.html           # 郵件 HTML 模板
├── state/
│   ├── sent.txt            # 已發送記錄（空檔案）
│   └── failed.txt          # 失敗記錄（空檔案）
└── logs/                    # 日誌目錄（自動建立）
```

---

## 📋 檔案建立順序與說明

### 第一階段：建立目錄結構

```bash
mkdir mail_cil
cd mail_cil
mkdir templates
mkdir state
mkdir logs
```

### 第二階段：建立核心程式檔案

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 01 | send_cli.py | FILE_01_send_cli.py.txt | 原版主程式（純互動式） |
| 02 | enhanced_send_cli.py | FILE_02_enhanced_send_cli.py.txt | 增強版主程式（支援設定檔） |
| 03 | ssh_tunnel.py | FILE_03_ssh_tunnel.py.txt | SSH tunnel 模組 |
| 04 | resend_provider.py | FILE_04_resend_provider.py.txt | Resend API 提供者 |
| 05 | adaptive.py | FILE_05_adaptive.py.txt | 自適應速率控制 |

### 第三階段：建立設定與配置

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 06 | config.ini | FILE_06_config.ini.txt | 設定檔（請自行編輯填入資訊） |
| 07 | requirements.txt | FILE_07_requirements.txt.txt | Python 依賴套件清單 |

### 第四階段：建立啟動腳本

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 08 | run.bat | FILE_08_run.bat.txt | Windows 一鍵啟動腳本 |
| 09 | run.sh | FILE_09_run.sh.txt | Linux/Mac 一鍵啟動腳本 |

### 第五階段：建立範例與模板

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 10 | recipients.txt | FILE_10_recipients.txt.txt | 收件人清單範例 |
| 11 | templates/mail.html | FILE_11_mail_html.txt | 郵件 HTML 模板 |

### 第六階段：建立狀態追蹤檔案（空檔案）

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 12 | state/sent.txt | FILE_12_sent_txt.txt | 已發送記錄（空檔案） |
| 13 | state/failed.txt | FILE_13_failed_txt.txt | 失敗記錄（空檔案） |

### 第七階段：建立文件檔案

| 編號 | 檔案名稱 | 文字檔名稱 | 說明 |
|------|---------|-----------|------|
| 14 | README.md | FILE_14_README.md.txt | 完整使用說明 |
| 15 | QUICKSTART.md | FILE_15_QUICKSTART.md.txt | 快速開始指南 |
| 16 | CHANGES.md | FILE_16_CHANGES.md.txt | 變更說明 |

---

## 🚀 建立步驟詳解

### Step 1: 建立目錄

```bash
mkdir mail_cil
cd mail_cil
mkdir templates state logs
```

### Step 2: 建立核心程式檔案

從文字檔案複製內容到對應檔案：

```bash
# Windows (PowerShell)
Get-Content FILE_01_send_cli.py.txt | Set-Content send_cli.py -Encoding UTF8
Get-Content FILE_02_enhanced_send_cli.py.txt | Set-Content enhanced_send_cli.py -Encoding UTF8
Get-Content FILE_03_ssh_tunnel.py.txt | Set-Content ssh_tunnel.py -Encoding UTF8
Get-Content FILE_04_resend_provider.py.txt | Set-Content resend_provider.py -Encoding UTF8
Get-Content FILE_05_adaptive.py.txt | Set-Content adaptive.py -Encoding UTF8

# Linux/Mac
cat FILE_01_send_cli.py.txt > send_cli.py
cat FILE_02_enhanced_send_cli.py.txt > enhanced_send_cli.py
cat FILE_03_ssh_tunnel.py.txt > ssh_tunnel.py
cat FILE_04_resend_provider.py.txt > resend_provider.py
cat FILE_05_adaptive.py.txt > adaptive.py
```

### Step 3: 建立設定檔

```bash
# Windows
Get-Content FILE_06_config.ini.txt | Set-Content config.ini -Encoding UTF8

# Linux/Mac
cat FILE_06_config.ini.txt > config.ini
```

**重要**：編輯 `config.ini`，填入您的 API Key 等資訊！

### Step 4: 建立依賴檔案

```bash
# Windows
Get-Content FILE_07_requirements.txt.txt | Set-Content requirements.txt -Encoding UTF8

# Linux/Mac
cat FILE_07_requirements.txt.txt > requirements.txt
```

### Step 5: 建立啟動腳本

```bash
# Windows
Get-Content FILE_08_run.bat.txt | Set-Content run.bat -Encoding UTF8

# Linux/Mac
cat FILE_09_run.sh.txt > run.sh
chmod +x run.sh
```

### Step 6: 建立範例檔案

```bash
# Windows
Get-Content FILE_10_recipients.txt.txt | Set-Content recipients.txt -Encoding UTF8
Get-Content FILE_11_mail_html.txt | Set-Content templates\mail.html -Encoding UTF8

# Linux/Mac
cat FILE_10_recipients.txt.txt > recipients.txt
cat FILE_11_mail_html.txt > templates/mail.html
```

### Step 7: 建立狀態檔案（空檔案）

```bash
# Windows
New-Item state/sent.txt -ItemType File
New-Item state/failed.txt -ItemType File

# Linux/Mac
touch state/sent.txt
touch state/failed.txt
```

### Step 8: 建立文件檔案

```bash
# Windows
Get-Content FILE_14_README.md.txt | Set-Content README.md -Encoding UTF8
Get-Content FILE_15_QUICKSTART.md.txt | Set-Content QUICKSTART.md -Encoding UTF8
Get-Content FILE_16_CHANGES.md.txt | Set-Content CHANGES.md -Encoding UTF8

# Linux/Mac
cat FILE_14_README.md.txt > README.md
cat FILE_15_QUICKSTART.md.txt > QUICKSTART.md
cat FILE_16_CHANGES.md.txt > CHANGES.md
```

---

## ✅ 完成檢查清單

- [ ] 目錄結構已建立（mail_cil, templates, state, logs）
- [ ] 核心程式檔案已建立（5個 .py 檔案）
- [ ] 設定檔已建立並編輯（config.ini）
- [ ] 依賴檔案已建立（requirements.txt）
- [ ] 啟動腳本已建立（run.bat, run.sh）
- [ ] 範例檔案已建立（recipients.txt, templates/mail.html）
- [ ] 狀態檔案已建立（state/sent.txt, state/failed.txt）
- [ ] 文件檔案已建立（README.md, QUICKSTART.md, CHANGES.md）

---

## 🎯 建立完成後的下一步

### 1. 編輯設定檔
開啟 `config.ini`，填入：
- API Key
- 寄件者 Email 和名稱
- 其他必要的設定

### 2. 準備收件人清單
編輯 `recipients.txt`，填入要發送的 Email 地址

### 3. 執行程式
- Windows: 雙擊 `run.bat`
- Linux/Mac: 執行 `./run.sh`

---

## 📞 需要幫助？

如果遇到問題，請參考：
- `README.md` - 完整使用說明
- `QUICKSTART.md` - 快速開始指南
- `CHANGES.md` - 技術變更說明

---

**提示**：所有的文字檔案都沒有副檔名限制，直接複製內容即可！