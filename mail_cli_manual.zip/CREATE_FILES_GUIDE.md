# Mail CLI - 手動建立檔案指南

## 📋 檔案清單

請依照以下順序建立檔案。

### 核心程式檔案
1. send_cli.py - 原版主程式
2. enhanced_send_cli.py - 增強版主程式（支援設定檔）
3. ssh_tunnel.py - SSH tunnel 模組
4. resend_provider.py - Resend API 提供者
5. adaptive.py - 自適應速率控制

### 設定與配置
6. config.ini - 設定檔
7. requirements.txt - Python 依賴套件

### 啟動腳本
8. run.bat - Windows 一鍵啟動腳本
9. run.sh - Linux/Mac 一鍵啟動腳本

### 範例與模板
10. recipients.txt - 收件人清單範例
11. templates/mail.html - 郵件 HTML 模板

### 狀態追蹤（空檔案）
12. state/sent.txt - 已發送記錄（空檔案）
13. state/failed.txt - 失敗記錄（空檔案）

### 文件檔案
14. README.md - 完整使用說明
15. QUICKSTART.md - 快速開始指南
16. CHANGES.md - 變更說明

---

## 🚀 快速建立步驟

### 第 1 步：建立目錄結構

```bash
mkdir mail_cil
cd mail_cil
mkdir templates
mkdir state
mkdir logs
```

### 第 2 步：建立檔案

每個檔案的內容都會在後續單獨提供。

### 第 3 步：給予執行權限（Linux/Mac）

```bash
chmod +x run.sh
```

### 第 4 步：執行

Windows: run.bat
Linux/Mac: ./run.sh

---

**接下來我會為您創建每個檔案的內容檔案。**