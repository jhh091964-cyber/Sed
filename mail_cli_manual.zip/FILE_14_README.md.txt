# Mail CLI - 批量郵件發送工具

## 概述

這是一個支援批量發送郵件的命令列工具，具備以下特色：

- **並發發送**：支援高併發發送，可自訂同時發送數量
- **SSH Tunnel 支援**：可透過 SSH tunnel 建立安全的 SOCKS5 代理
- **智慧速率控制**：自動調整發送速率，避免觸發限制
- **已發送追蹤**：自動記錄已發送郵件，避免重複發送
- **完整統計**：提供詳細的發送統計與錯誤分析
- **日誌記錄**：JSON 格式的詳細發送記錄
- **設定檔支援**：支援設定檔，免去每次輸入參數的麻煩
- **一鍵啟動**：提供啟動腳本，自動安裝依賴並執行

---

## 快速開始

### Windows 用戶

1. 雙擊 `run.bat`
2. 按照提示輸入資訊（或編輯 config.ini 預先設定）
3. 開始發送！

### Linux/Mac 用戶

```bash
chmod +x run.sh
./run.sh
```

### 手動安裝（如需）

```bash
# 建立虛擬環境
python -m venv venv

# 啟動虛擬環境
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 安裝套件
pip install -r requirements.txt

# 編輯 config.ini 填入設定

# 執行
python enhanced_send_cli.py
```

---

## 已發送追蹤機制

### 工作原理

1. **成功發送**：Email 會記錄到 `state/sent.txt`
2. **發送失敗**：Email 會記錄到 `state/failed.txt`
3. **下次執行**：啟用「跳過已發送」後，會自動跳過已存在的 Email

### 重置記錄

```bash
# Windows
rmdir /S state

# Linux/Mac
rm -rf state/
```

---

## 發送統計

程式結束時會顯示：
```
📊 發送統計總結
==================================================
Total:       1000
Attempted:   800
Success:     750
Failed:      50
Skipped:     200
Success Rate: 93.75%

🔴 Top Failure Reasons:
  1. Rate limit (429) (30x)
  2. Server error (500) (15x)
```

---

## 系統需求

- Python 3.8 或更高版本
- 網路連線
- Resend API Key（請至 https://resend.com 註冊）

---

## 注意事項

1. **API Key 安全**：請勿將包含真實 API Key 的檔案分享給他人
2. **收件人清單**：請確保收件人同意接收郵件，遵守相關法規
3. **發送速率**：建議合理設定併發數（預設 50），避免觸發速率限制
4. **日誌管理**：logs/send.jsonl 會持續增長，建議定期清理

---

## 故障排除

### 連線錯誤
1. 檢查網路連線
2. 確認 API Key 正確
3. 如果使用 SSH tunnel，確認 SSH 伺服器可連線

### 速率限制
如果出現 "Rate limit (429)" 錯誤：
1. 降低併發數（例如從 50 降到 20）
2. 程式會自動調整發送速率
3. 等待一段時間後再試

---

## 版本資訊

- 版本：2.1（簡易版）
- 發布日期：2024-02-04
- 相容性：Python 3.8+, Windows, Linux, macOS