# Mail CLI - 檔案建立總索引

## 📋 檔案清單

以下所有檔案都已創建完成，請依照檔名建立對應的實體檔案。

---

## 🚀 核心程式檔案

### 1. send_cli.py
**檔案名稱**：`FILE_01_send_cli.py.txt`
**建立為**：`send_cli.py`
**說明**：原版主程式，含統計與追蹤功能

### 2. enhanced_send_cli.py
**檔案名稱**：`FILE_02_enhanced_send_cli.py.txt`
**建立為**：`enhanced_send_cli.py`
**說明**：增強版主程式，支援設定檔

### 3. ssh_tunnel.py
**檔案名稱**：`FILE_03_ssh_tunnel.py.txt`
**建立為**：`ssh_tunnel.py`
**說明**：SSH tunnel 模組

### 4. resend_provider.py
**檔案名稱**：`FILE_04_resend_provider.py.txt`
**建立為**：`resend_provider.py`
**說明**：Resend API 提供者

### 5. adaptive.py
**檔案名稱**：`FILE_05_adaptive.py.txt`
**建立為**：`adaptive.py`
**說明**：自適應速率控制

---

## ⚙️ 設定與配置

### 6. config.ini
**檔案名稱**：`FILE_06_config.ini.txt`
**建立為**：`config.ini`
**說明**：設定檔（填入您的資訊）

### 7. requirements.txt
**檔案名稱**：`FILE_07_requirements.txt.txt`
**建立為**：`requirements.txt`
**說明**：Python 依賴套件

---

## 🎯 啟動腳本

### 8. run.bat
**檔案名稱**：`FILE_08_run.bat.txt`
**建立為**：`run.bat`
**說明**：Windows 一鍵啟動腳本

### 9. run.sh
**檔案名稱**：`FILE_09_run.sh.txt`
**建立為**：`run.sh`
**說明**：Linux/Mac 一鍵啟動腳本
**注意**：建立後需執行 `chmod +x run.sh`

---

## 📄 範例與模板

### 10. recipients.txt
**檔案名稱**：`FILE_10_recipients.txt.txt`
**建立為**：`recipients.txt`
**說明**：收件人清單範例

### 11. templates/mail.html
**檔案名稱**：`FILE_11_mail_html.txt`
**建立為**：`templates/mail.html`
**說明**：郵件 HTML 模板
**注意**：需要先建立 `templates/` 目錄

---

## 📊 狀態追蹤檔案

### 12. state/sent.txt
**檔案名稱**：`FILE_12_sent_txt.txt`
**建立為**：`state/sent.txt`
**說明**：已發送記錄（空檔案）
**注意**：需要先建立 `state/` 目錄

### 13. state/failed.txt
**檔案名稱**：`FILE_13_failed_txt.txt`
**建立為**：`state/failed.txt`
**說明**：失敗記錄（空檔案）
**注意**：需要先建立 `state/` 目錄

---

## 📖 文件檔案

### 14. README.md
**檔案名稱**：`FILE_14_README.md.txt`
**建立為**：`README.md`
**說明**：完整使用說明

### 15. QUICKSTART.md
**檔案名稱**：`FILE_15_QUICKSTART.md.txt`
**建立為**：`QUICKSTART.md`
**說明**：快速開始指南

### 16. CHANGES.md
**檔案名稱**：`FILE_16_CHANGES.md.txt`
**建立為**：`CHANGES.md`
**說明**：變更說明文件

---

## 🛠️ 建立步驟

### 第 1 步：建立目錄結構

**Windows**:
```cmd
mkdir mail_cil
cd mail_cil
mkdir templates
mkdir state
mkdir logs
```

**Linux/Mac**:
```bash
mkdir mail_cil
cd mail_cil
mkdir templates
mkdir state
mkdir logs
```

### 第 2 步：建立檔案

對每個檔案：
1. 開啟對應的 `FILE_XX_名稱.txt`
2. 複製全部內容
3. 建立對應的實體檔案（參考上表）
4. 貼上內容並儲存

### 第 3 步：賦予執行權限（Linux/Mac）

```bash
chmod +x run.sh
```

### 第 4 步：編輯設定檔

開啟 `config.ini`，填入您的資訊：
```ini
[account]
api_key = your_resend_api_key

[email]
from_email = sender@example.com
from_name = Your Name
```

### 第 5 步：執行

**Windows**: 雙擊 `run.bat`

**Linux/Mac**: 執行 `./run.sh`

---

## 📝 檔案對照表

| # | 原始檔名 | 目標檔名 | 目錄 |
|---|----------|----------|------|
| 1 | FILE_01_send_cli.py.txt | send_cli.py | 根目錄 |
| 2 | FILE_02_enhanced_send_cli.py.txt | enhanced_send_cli.py | 根目錄 |
| 3 | FILE_03_ssh_tunnel.py.txt | ssh_tunnel.py | 根目錄 |
| 4 | FILE_04_resend_provider.py.txt | resend_provider.py | 根目錄 |
| 5 | FILE_05_adaptive.py.txt | adaptive.py | 根目錄 |
| 6 | FILE_06_config.ini.txt | config.ini | 根目錄 |
| 7 | FILE_07_requirements.txt.txt | requirements.txt | 根目錄 |
| 8 | FILE_08_run.bat.txt | run.bat | 根目錄 |
| 9 | FILE_09_run.sh.txt | run.sh | 根目錄 |
| 10 | FILE_10_recipients.txt.txt | recipients.txt | 根目錄 |
| 11 | FILE_11_mail_html.txt | mail.html | templates/ |
| 12 | FILE_12_sent_txt.txt | sent.txt | state/ |
| 13 | FILE_13_failed_txt.txt | failed.txt | state/ |
| 14 | FILE_14_README.md.txt | README.md | 根目錄 |
| 15 | FILE_15_QUICKSTART.md.txt | QUICKSTART.md | 根目錄 |
| 16 | FILE_16_CHANGES.md.txt | CHANGES.md | 根目錄 |

---

## ✅ 完成檢查

建立完所有檔案後，您的目錄結構應該是：

```
mail_cil/
├── send_cli.py              ✓
├── enhanced_send_cli.py     ✓
├── ssh_tunnel.py            ✓
├── resend_provider.py       ✓
├── adaptive.py              ✓
├── config.ini               ✓
├── requirements.txt         ✓
├── run.bat                  ✓
├── run.sh                   ✓
├── recipients.txt           ✓
├── README.md                ✓
├── QUICKSTART.md            ✓
├── CHANGES.md               ✓
├── templates/
│   └── mail.html            ✓
├── state/
│   ├── sent.txt             ✓
│   └── failed.txt           ✓
└── logs/                    ✓
```

---

## 💡 提示

1. **檔案編碼**：所有檔案都使用 UTF-8 編碼
2. **檔案權限**：`run.sh` 需要執行權限
3. **設定檔**：`config.ini` 請填入真實資訊
4. **收件人**：`recipients.txt` 請填入真實收件人
5. **模板**：`templates/mail.html` 可根據需求修改

---

## 🎯 快速開始

建立完成後：

1. 編輯 `config.ini` 和 `recipients.txt`
2. 雙擊 `run.bat`（Windows）或執行 `./run.sh`（Linux/Mac）
3. 開始發送！

---

**所有檔案已準備完成，請依照此索引建立您的專案！**