╔════════════════════════════════════════════════════════════════╗
║           Mail CLI - 手動建立檔案套件                          ║
║           Manual File Creation Package                         ║
╚════════════════════════════════════════════════════════════════╝

感謝您使用 Mail CLI！

這個 ZIP 包含建立 Mail CLI 專案所需的所有檔案內容。
請依照以下步驟建立您的專案。

═════════════════════════════════════════════════════════════════

📋 套件內容
═════════════════════════════════════════════════════════════════

核心程式檔案 (5個)：
  FILE_01_send_cli.py.txt          → send_cli.py
  FILE_02_enhanced_send_cli.py.txt → enhanced_send_cli.py
  FILE_03_ssh_tunnel.py.txt        → ssh_tunnel.py
  FILE_04_resend_provider.py.txt   → resend_provider.py
  FILE_05_adaptive.py.txt          → adaptive.py

設定與配置 (2個)：
  FILE_06_config.ini.txt           → config.ini
  FILE_07_requirements.txt.txt     → requirements.txt

啟動腳本 (2個)：
  FILE_08_run.bat.txt              → run.bat (Windows)
  FILE_09_run.sh.txt               → run.sh (Linux/Mac)

範例與模板 (2個)：
  FILE_10_recipients.txt.txt       → recipients.txt
  FILE_11_mail_html.txt            → templates/mail.html

狀態追蹤 (2個空檔案)：
  FILE_12_sent_txt.txt             → state/sent.txt
  FILE_13_failed_txt.txt           → state/failed.txt

文件檔案 (3個)：
  FILE_14_README.md.txt            → README.md
  FILE_15_QUICKSTART.md.txt        → QUICKSTART.md
  FILE_16_CHANGES.md.txt           → CHANGES.md

索引檔案 (3個)：
  MASTER_INDEX.md                  - 主要建立指南
  ALL_FILES_INDEX.md               - 完整檔案對照表
  CREATE_FILES_GUIDE.md            - 建立步驟指南

═════════════════════════════════════════════════════════════════

🚀 快速開始 (3步驟)
═════════════════════════════════════════════════════════════════

第 1 步：建立目錄結構
═════════════════════════════════════════════════════════════════

Windows:
  mkdir mail_cil
  cd mail_cil
  mkdir templates
  mkdir state
  mkdir logs

Linux/Mac:
  mkdir mail_cil
  cd mail_cil
  mkdir templates
  mkdir state
  mkdir logs

═════════════════════════════════════════════════════════════════

第 2 步：建立檔案
═════════════════════════════════════════════════════════════════

對每個 FILE_XX_名稱.txt 檔案：

1. 開啟該文字檔
2. 複製全部內容
3. 建立對應的實體檔案（參照上方清單）
4. 貼上內容並儲存

例如：
  開啟 FILE_01_send_cli.py.txt
  複製內容 → 建立新檔案 send_cli.py → 貼上 → 儲存

═════════════════════════════════════════════════════════════════

第 3 步：設定並執行
═════════════════════════════════════════════════════════════════

1. 編輯 config.ini，填入：
   - API Key (從 https://resend.com 取得)
   - 寄件者 Email
   - 寄件者名稱

2. 編輯 recipients.txt，填入收件人清單

3. Linux/Mac 使用者需執行：
   chmod +x run.sh

4. 執行程式：
   Windows: 雙擊 run.bat
   Linux/Mac: ./run.sh

═════════════════════════════════════════════════════════════════

📖 詳細說明
═════════════════════════════════════════════════════════════════

請閱讀以下檔案了解更多：

  MASTER_INDEX.md         - 完整的建立指南（推薦先看這個）
  ALL_FILES_INDEX.md      - 詳細的檔案對照表
  CREATE_FILES_GUIDE.md   - 逐步建立說明

建立完成後可參考：

  README.md               - 完整使用說明
  QUICKSTART.md           - 快速開始指南
  CHANGES.md              - 變更說明

═════════════════════════════════════════════════════════════════

💡 重要提示
═════════════════════════════════════════════════════════════════

✓ 所有檔案都使用 UTF-8 編碼
✓ Linux/Mac 使用者需給予 run.sh 執行權限
✓ config.ini 請填入真實的 API Key
✓ recipients.txt 請填入真實的收件人
✓ 首次使用建議先用 5-10 封郵件測試

═════════════════════════════════════════════════════════════════

✅ 完成檢查
═════════════════════════════════════════════════════════════════

建立完成後，您的目錄結構應該是：

mail_cil/
├── send_cli.py              ✓
├── enhanced_send_cli.py     ✓
├── ssh_tunnel.py            ✓
├── resend_provider.py       ✓
├── adaptive.py              ✓
├── config.ini               ✓ (需填入資訊)
├── requirements.txt         ✓
├── run.bat                  ✓
├── run.sh                   ✓ (需執行權限)
├── recipients.txt           ✓ (需填入收件人)
├── README.md                ✓
├── QUICKSTART.md            ✓
├── CHANGES.md               ✓
├── templates/
│   └── mail.html            ✓
├── state/
│   ├── sent.txt             ✓
│   └── failed.txt           ✓
└── logs/                    ✓

═════════════════════════════════════════════════════════════════

🔍 檔案資訊
═════════════════════════════════════════════════════════════════

檔案名稱：mail_cli_manual.zip
檔案大小：55,128 bytes
檔案數量：19 個檔案
SHA256：3d0dc04d763fd92e5ba04a2997536f79fa42a355e4867060b4af67bea64818d2

驗證指令：
  Windows: certutil -hashfile mail_cli_manual.zip SHA256
  Linux/Mac: sha256sum mail_cli_manual.zip

═════════════════════════════════════════════════════════════════

🎯 下一步
═════════════════════════════════════════════════════════════════

1. 先閱讀 MASTER_INDEX.md 了解整體結構
2. 依照步驟建立所有檔案
3. 編輯 config.ini 和 recipients.txt
4. 執行 run.bat 或 run.sh
5. 開始發送郵件！

═════════════════════════════════════════════════════════════════

如有任何問題，請參考：
  • README.md - 完整使用說明
  • QUICKSTART.md - 快速開始指南
  • CHANGES.md - 技術變更說明

祝您使用愉快！
═════════════════════════════════════════════════════════════════

版本：2.1 (簡易版)
發布日期：2024-02-04
═════════════════════════════════════════════════════════════════